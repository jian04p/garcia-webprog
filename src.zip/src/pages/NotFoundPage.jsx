const NotFoundPage = () => {
  return (
    <div className="mx-auto max-w-3xl px-4 pt-32 sm:px-6 lg:px-8">
      <section className="rounded-[32px] border border-[#181716] bg-[#fffaf2]/90 p-8 shadow-[0_24px_70px_rgba(24,23,22,0.08)]">
        <h1 className="text-3xl font-semibold tracking-[-0.04em] text-[#181716]">Page Not Found</h1>
        <p className="mt-3 text-base leading-7 text-[#4d473f]">
          The link you followed to get here must be broken...
        </p>
      </section>
    </div>
  );
};

export default NotFoundPage;
